"""
pyanzo_interface - Python interface for Altair Graph Studio (Anzo).

This package provides a programmatic interface for managing Anzo graphmarts,
layers, and steps without requiring the AGS UI. Designed for use in automation
pipelines, Databricks notebooks, and DevOps workflows.
"""

from .graphmart_manager import GraphmartManagerApi, GraphmartManagerApiException

__version__ = "1.0.0"
__all__ = ["GraphmartManagerApi", "GraphmartManagerApiException"]
